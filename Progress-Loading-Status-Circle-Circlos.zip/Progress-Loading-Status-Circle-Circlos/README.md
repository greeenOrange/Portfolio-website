## jQuery-Circle-Plugin 

Circlos Is a jQuery library that enables you to make Circle progress easily and quickly with the possibility to add colors and control the duration and the size of the circle

![Circlos demo](screenshots/Circle_progress.png)

Documentation in progress ...
